package co.gov.mintic.ciclo3.ProyectoFinal.ingresoEgreso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IngresoEgresoApplicationTests {

	@Test
	void contextLoads() {
	}

}
