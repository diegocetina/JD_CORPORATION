package co.gov.mintic.ciclo3.ProyectoFinal.ingresoEgreso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IngresoEgresoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IngresoEgresoApplication.class, args);
	}

}
